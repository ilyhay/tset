﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DE2
{
    /// <summary>
    /// Логика взаимодействия для ClientsPage.xaml
    /// </summary>
    public partial class CreateNewTagWindow : Window
    {
        public CreateNewTagWindow()
        {
            InitializeComponent();
        }

        private void btn_Create_Click(object sender, RoutedEventArgs e)
        {
            if (tb_Title.Text.Length > 30)
                MessageBox.Show("Слишком длинное название тега: максимум 30 символов");
            if (tb_Title.Text == "" || tb_Color.Text == "")
                MessageBox.Show("Необходимо ввести название и цвет тега");
            else
            {
                Model.Tag newTag = new Model.Tag();
                newTag.Title = tb_Title.Text;
                newTag.Color = tb_Color.Text;

                Helper.GetContext().Tag.Add(newTag);
                Helper.GetContext().SaveChanges();

                Close();
            }
        }

        private void btn_Cancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        // Обработчик события PreviewTextInput для tb_Title
        private void tb_Title_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("^[a-zA-Z]*$"); // Регулярное выражение для английских букв
            e.Handled = !regex.IsMatch(e.Text);
        }

        // Обработчик события PreviewTextInput для tb_Color
        private void tb_Color_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("^[a-zA-Z]*$"); // Регулярное выражение для английских букв
            e.Handled = !regex.IsMatch(e.Text);
        }
    }
}
