﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DE2
{
    /// <summary>
    /// Логика взаимодействия для AddEditClientWindow.xaml
    /// </summary>

    public class GenderToBooleanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return (value?.ToString() == parameter?.ToString());
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return (bool)value ? parameter.ToString() : null;
        }
    }
    public partial class AddEditClientWindow : Window
    {
        public List<Model.Tag> listTags = new List<Model.Tag>();//Список тегов клиента

        private Model.Client client = new Model.Client();
        public AddEditClientWindow(Model.Client cl)
        {
            InitializeComponent();
            client = cl ?? new Model.Client();
            this.DataContext = client;

            if (client.ID != 0)
            {
                client = cl;

                tbl_ID.Text = client.ID.ToString();
                tb_LastName.Text = client.LastName;
                tb_FirstName.Text = client.FirstName;
                tb_Patronymic.Text = client.Patronymic;
                tb_Email.Text = client.Email;
                tb_Phone.Text = client.Phone.Trim(Convert.ToChar(160));
                dp_Birthday.SelectedDate = client.Birthday;
                // Задаем выбранное значение RadioButton на основе GenderCode
                if (client.GenderCode == "2") // Мужской
                {
                    rb_Male.IsChecked = true;
                }
                else if (client.GenderCode == "1") // Женский
                {
                    rb_Female.IsChecked = true;
                }
                // Установка пути к фотографии
                if (!string.IsNullOrEmpty(client.PhotoPath))
                {
                    // Получаем полный путь
                    string fullPath = System.IO.Path.Combine(Directory.GetCurrentDirectory(), client.PhotoPath);
                    if (File.Exists(fullPath))
                    {
                        var bitmap = new BitmapImage();
                        using (var stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read))
                        {
                            bitmap.BeginInit();
                            bitmap.CacheOption = BitmapCacheOption.OnLoad; // Загружаем изображение в память.
                            bitmap.StreamSource = stream;
                            bitmap.EndInit();
                            bitmap.Freeze(); // Разрешаем доступ из других потоков.
                        }

                        img_Photo.Source = bitmap;
                    }
                    else
                    {
                        MessageBox.Show("Файл фотографии не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                listTags = client.Tag.ToList();
                lv_Tags.ItemsSource = listTags;
            }
        }
        private void btn_EditPhoto_Click(object sender, RoutedEventArgs e)
        {
            string defaultDirectory = Directory.GetParent(Environment.CurrentDirectory).Parent.FullName + "\\Клиенты\\"; //Папка изображений по умолчанию

            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png)|*.jpg;*.png;*.jpeg";
            fileDialog.Title = "Выбор фотографии клиента";
            fileDialog.InitialDirectory = defaultDirectory;

            if (fileDialog.ShowDialog() == true)
            {
                try
                {
                    FileInfo selectedImage = new FileInfo(fileDialog.FileName); //Выбранное изображение
                    string imageName = selectedImage.Name; //Название изображения
                    try
                    {
                        selectedImage.CopyTo(defaultDirectory + imageName); //Копирование изображение в папку по умолчанию
                    }
                    catch { };
                    img_Photo.Source = new ImageSourceConverter().ConvertFromString(defaultDirectory + imageName) as ImageSource; //Вывод фотографии в окне
                    client.PhotoPath = "Клиенты/" + imageName; //Запись пути к фотографии
                }
                catch
                {
                    MessageBox.Show("Не удалось сохранить изображение");
                }
            }
        }

        //Проверка полей
        private bool CheckingFields()
        {
            string message = ""; //Сообщение об ошибкке

            if (!Regex.IsMatch(tb_LastName.Text, @"^[a-zA-zа-яА-Я- ]+$") || !Regex.IsMatch(tb_FirstName.Text, @"^[a-zA-zа-яА-Я- ]+$") || !Regex.IsMatch(tb_Patronymic.Text, @"^[a-zA-zа-яА-Я- ]*$"))
            {
                if (tb_LastName.Text == "")
                    message += "Необходимо указать фамилию\n";
                if (tb_FirstName.Text == "")
                    message += "Необходимо указать имя\n";
                else
                    message += "Поля ФИО могут содержать в себе только буквы и следующие символы: пробел и дефис\n";
            }
            if (tb_LastName.Text.Length > 50 || tb_FirstName.Text.Length > 50 || tb_Patronymic.Text.Length > 50)
                message += "Поля фамилии, имени и отчества не могут быть длиннее 50 символов\n";

            var email = new EmailAddressAttribute();
            if (!email.IsValid(tb_Email.Text))
                message += "Email введен некорректно\n";
            if (!Regex.IsMatch(tb_Phone.Text, @"^[0-9() +-]+$"))
            {
                if (tb_Phone.Text == "")
                    message += "Необходимо указать телефон\n";
                else
                    message += "Поле телефона может содержать только цифры и следующие символы: плюс, минус, открывающая и закрывающая круглые скобки, знак пробела\n" + Convert.ToInt32(tb_Phone.Text[tb_Phone.Text.Length - 1]);
            }
            if (dp_Birthday.SelectedDate == null)
                message += "Необходимо указать дату рождения\n";
            if (rb_Male.IsChecked == false && rb_Female.IsChecked == false)
                message += "Необходимо указать пол\n";

            //Вывод сообщения об ошибках, если они есть
            if (message != "")
            {
                MessageBox.Show(message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            else
                return true;
        }

        //Выбор тега из списка
        private void lv_Tags_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btn_DeleteTag.IsEnabled = true;
        }
        private void btn_AddTag_Click(object sender, RoutedEventArgs e)
        {
            AddTagWindow addTagWindow = new AddTagWindow();
            addTagWindow.Owner = this;
            addTagWindow.ShowDialog();
            lv_Tags.SelectedIndex = -1;
            lv_Tags.ItemsSource = null;
            lv_Tags.ItemsSource = listTags;
        }
        private void btn_DeleteTag_Click(object sender, RoutedEventArgs e)
        {
            foreach (var tag in lv_Tags.SelectedItems)
            {
                listTags.Remove(tag as Model.Tag);
            }
            lv_Tags.SelectedIndex = -1;
            lv_Tags.ItemsSource = null;
            lv_Tags.ItemsSource = listTags;
            btn_DeleteTag.IsEnabled = false;
        }

        private void btn_Save_Click(object sender, RoutedEventArgs e)
        {
            if (CheckingFields())
            {
                try
                {
                    client.LastName = tb_LastName.Text;
                    client.FirstName = tb_FirstName.Text;
                    client.Patronymic = tb_Patronymic.Text;
                    client.Email = tb_Email.Text;
                    client.Phone = tb_Phone.Text;
                    client.Birthday = dp_Birthday.SelectedDate;
                    client.RegistrationDate = DateTime.Now;
                    client.GenderCode = rb_Male.IsChecked == true ? "м" : "ж"; // Если другой порядок, исправьте его

                    // Проверка на уникальность email и телефона
                    var existingClient = Helper.GetContext().Client
                        .FirstOrDefault(c => c.Email == client.Email && c.ID != client.ID);

                    if (existingClient != null)
                    {
                        MessageBox.Show("Клиент с таким email уже существует.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    existingClient = Helper.GetContext().Client
                        .FirstOrDefault(c => c.Phone == client.Phone && c.ID != client.ID);

                    if (existingClient != null)
                    {
                        MessageBox.Show("Клиент с таким номером телефона уже существует.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    client.Tag.Clear();
                    client.Tag = listTags;

                    // Добавление или редактирование
                    if (string.IsNullOrEmpty(tbl_ID.Text)) // Если это новый клиент
                    {
                        Helper.GetContext().Client.Add(client);
                    }

                    // Сохраняем изменения
                    Helper.GetContext().SaveChanges();
                    this.Close(); // Закрываем окно после успешного сохранения
                }
                catch (Exception ex)
                {
                    // Подробная обработка ошибок
                    MessageBox.Show("Произошла ошибка при сохранении клиента: " + ex.Message + "\n" + ex.InnerException?.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

        }

        private void btn_Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
