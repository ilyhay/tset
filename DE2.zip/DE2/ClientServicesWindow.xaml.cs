﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DE2
{
    /// <summary>
    /// Логика взаимодействия для ClientServicesWindow.xaml
    /// </summary>
    public partial class ClientServicesWindow : Window
    {
        public ClientServicesWindow(Model.Client client)
        {
            InitializeComponent();

            tbl_Title.Text = "Список посещений клиента №" + client.ID + " - " + client.LastName + " " + client.FirstName + " " + client.Patronymic;
            dg_Services.ItemsSource = client.ClientService;
        }
    }
}
