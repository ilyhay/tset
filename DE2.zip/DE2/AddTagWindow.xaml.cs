﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DE2
{
    /// <summary>
    /// Логика взаимодействия для AddTagWindow.xaml
    /// </summary>
    public partial class AddTagWindow : Window
    {
        public AddTagWindow()
        {
            InitializeComponent();
            lv_Tags.ItemsSource = Helper.GetContext().Tag.OrderBy(t => t.ID).ToList();
        }

        private void btn_AddTag_Click(object sender, RoutedEventArgs e)
        {
            AddEditClientWindow owner = this.Owner as AddEditClientWindow;
            foreach (Model.Tag tag in lv_Tags.SelectedItems)
            {
                owner.listTags.Add(tag);
            }
            Close();
        }

        private void btn_Cancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btn_CreateTag_Click(object sender, RoutedEventArgs e)
        {
            CreateNewTagWindow createNewTagWindow = new CreateNewTagWindow();
            createNewTagWindow.ShowDialog();

            lv_Tags.ItemsSource = Helper.GetContext().Tag.OrderBy(t => t.ID).ToList();
        }

        private void lv_Tags_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btn_AddTag.IsEnabled = true;
        }
    }
}
