﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DE2
{
    /// <summary>
    /// Логика взаимодействия для ClientsPage.xaml
    /// </summary>
    public partial class ClientsPage : Page
    {
        private int recordsOnPageNumber = 10; //Количество записей на странице
        private int currentPageNumber = 0; //Номер страницы

        private int filterIndex = 0; //Индекс выбранной строки фильтрации
        private string searchString = ""; //Введенная строка поиска
        private int sortingIndex = 0; //Индекс выбранной строки сортировки


        public ClientsPage()
        {
            InitializeComponent();

            LoadClientsGrid();
            GetFilterStrings();
            GetSortingStrings();
        }

        //Получение строк для фильтрации
        private void GetFilterStrings()
        {
            List<string> filterStrings = new List<string>() { "Все" };
            var genders = Helper.Entities.Gender.OrderBy(gender => gender.Code).ToList();
            foreach (var g in genders)
            {
                filterStrings.Add(g.Name);
            }
            cb_Filter.ItemsSource = filterStrings;
        }
        //Получение строк для сортировки
        private void GetSortingStrings()
        {
            List<string> sortingStrings = new List<string>() { "по ID", "по фамилиям (в алфавитном порядке)", "по дате последнего посещения (от новых к старым)", "по количеству посещений (от большего к меньшему)" };
            cb_Sorting.ItemsSource = sortingStrings;
        }

        //Выбор фильтра
        private void cb_Filter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            filterIndex = cb_Filter.SelectedIndex;
            currentPageNumber = 0;
            LoadClientsGrid();
        }
        //Изменение строки поиска
        private void tb_Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            searchString = tb_Search.Text;
            currentPageNumber = 0;
            LoadClientsGrid();
        }
        //Выбор сортировки
        private void cb_Sorting_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            sortingIndex = cb_Sorting.SelectedIndex;
            currentPageNumber = 0;
            LoadClientsGrid();
        }

        //Установка флажка проверки даты рождения
        private void chb_BirtdayInThisMonth_Checked(object sender, RoutedEventArgs e)
        {
            currentPageNumber = 0;
            LoadClientsGrid();
        }
        //Снятие флажка проверки даты рождения
        private void chb_BirtdayInThisMonth_Unchecked(object sender, RoutedEventArgs e)
        {
            currentPageNumber = 0;
            LoadClientsGrid();
        }

        //Изменение количества записей на странице
        private void btn_RecordsOnPageNumber_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;

            if (recordsOnPageNumber != Convert.ToInt32(btn.Tag))
            {
                recordsOnPageNumber = Convert.ToInt32(btn.Tag);
                currentPageNumber = 0;

                btn.Background = new SolidColorBrush(Color.FromRgb(255, 156, 26));
                foreach (var child in sp_RecordsOnPageNumber.Children)
                {
                    Button b = child as Button;
                    if (recordsOnPageNumber != Convert.ToInt32(b.Tag))
                        b.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
                }
                LoadClientsGrid();
            }
        }

        //Загрузка таблицы клиентов
        private void LoadClientsGrid()
        {
            List<Model.Client> clientsList;

            //Поиск
            if (searchString == "")
                clientsList = Helper.GetContext().Client.OrderBy(client => client.ID).ToList();
            else
                clientsList = Helper.GetContext().Client.OrderBy(client => client.ID).Where(client => client.LastName.Contains(searchString) || client.FirstName.Contains(searchString)
                || client.Patronymic.Contains(searchString) || client.Email.Contains(searchString) || client.Phone.Contains(searchString)).ToList();
            //Фильтрация
            if (filterIndex > 0)
            {
                var selectedGender = Helper.Entities.Gender.OrderBy(gender => gender.Name).ToList()[filterIndex - 1];
                clientsList = clientsList.Where(client => client.Gender.Name.Equals(selectedGender.Name)).ToList();
            }
            //Проверка на день рождения и вывод клиентов с днем рождения в этом месяце
            if (chb_BirtdayInThisMonth.IsChecked == true)
                clientsList = clientsList.Where(client => client.Birthday.HasValue && client.Birthday.Value.Month.Equals(DateTime.Now.Month)).ToList();
            //Сортировка
            switch (sortingIndex)
            {
                case 1:
                    clientsList = clientsList.OrderBy(client => client.LastName).ToList();
                    break;
                case 2:
                    clientsList = clientsList.OrderByDescending(client => client.LastVisitDateTime).ToList();
                    break;
                case 3:
                    clientsList = clientsList.OrderByDescending(client => client.NumberVisits).ToList();
                    break;
            }

            //Вывод списка клиентов
            if (recordsOnPageNumber == 0)
                clientsGrid.ItemsSource = clientsList;
            else
                clientsGrid.ItemsSource = clientsList.Skip(currentPageNumber * recordsOnPageNumber).Take(recordsOnPageNumber);

            //Снятие выделения с элемента списка и блокировка кнопок удаления и редактирования
            clientsGrid.SelectedValue = null;
            btn_EditClient.IsEnabled = false;
            btn_DeleteClient.IsEnabled = false;

            CreatePaginationButtons(clientsList);
            ChangeEnableBackForwardButtons(clientsList);
            OutputRecordsNumber(clientsList);
        }

        //Создание кнопок для пагинации
        private void CreatePaginationButtons(List<Model.Client> clientsList)
        {
            sp_Pagination.Children.Clear();
            int pageCount = (int)Math.Ceiling((double)clientsList.Count / recordsOnPageNumber);
            int pageNumber = 1;
            do
            {
                Button btn = new Button();
                btn.Width = 20;
                btn.Content = pageNumber;
                btn.Click += SelectPage_Click;

                //Изменение цвета активной кнопки выбора страницы
                if (pageNumber == currentPageNumber + 1)
                    btn.Background = new SolidColorBrush(Color.FromRgb(255, 156, 26));

                sp_Pagination.Children.Add(btn);
                pageNumber++;
            }
            while (pageNumber <= pageCount);
        }

        //Настройка активности кнопок btn_Back и btn_Forward
        private void ChangeEnableBackForwardButtons(List<Model.Client> clientsList)
        {
            if (currentPageNumber == 0)
                btn_Back.IsEnabled = false;
            else
                btn_Back.IsEnabled = true;

            if ((currentPageNumber + 1) * recordsOnPageNumber >= clientsList.Count || recordsOnPageNumber == 0)
                btn_Forward.IsEnabled = false;
            else
                btn_Forward.IsEnabled = true;
        }

        //Вывод количества записей
        private void OutputRecordsNumber(List<Model.Client> clientsList)
        {
            tb_CurrentRecordsNumber.Text = clientsList.Count.ToString();
            tb_AllRecordsNumber.Text = Helper.GetClientsQuantity().ToString();
        }

        //Пагинация - выбор страницы
        private void SelectPage_Click(object sender, RoutedEventArgs e)
        {
            Button currentBtn = sender as Button;
            if (currentBtn == btn_Back)
                currentPageNumber--;
            else if (currentBtn == btn_Forward)
                currentPageNumber++;
            else
                currentPageNumber = Convert.ToInt32(currentBtn.Content) - 1;
            LoadClientsGrid();
        }


        //Изменение выбора клиента в списке
        private void clientsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btn_EditClient.IsEnabled = true;
            btn_DeleteClient.IsEnabled = true;
        }

        //Удаление клиента
        private void btn_DeleteClient_Click(object sender, RoutedEventArgs e)
        {
            Model.Client client = clientsGrid.SelectedItem as Model.Client;

            MessageBoxResult messageRes = MessageBox.Show("Вы уверены, что хотите удалить выбранного клиента?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (messageRes == MessageBoxResult.Yes)
            {
                if (client.NumberVisits == 0)
                {
                    var tags = client.Tag.ToList();
                    foreach (var tag in tags)
                    {
                        Helper.GetContext().Tag.Remove(tag);
                    }
                    Helper.GetContext().Client.Remove(client);
                    Helper.GetContext().SaveChanges();

                    LoadClientsGrid();
                }
                else
                    MessageBox.Show("Удаление невозможно!\n У клиента есть посещения.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                btn_DeleteClient.IsEnabled = false;
            }
        }

        //Добавление или редактирование клиента
        private void btn_AddEditClient_Click(object sender, RoutedEventArgs e)
        {
            AddEditClientWindow addEditWindow;
            Button btn = sender as Button;
            if (btn.Content.ToString().Equals("Добавить"))
            {
                addEditWindow = new AddEditClientWindow(null);
                addEditWindow.Title = "Добавление клиента";
            }
            else
            {
                addEditWindow = new AddEditClientWindow(clientsGrid.SelectedItem as Model.Client);
                addEditWindow.Title = "Редактирование клиента";
            }
            addEditWindow.ShowDialog();
            LoadClientsGrid();
        }

        //Двойное нажатие на клиента, чтобы открыть его список посещений
        private void OpenListServices(object sender, RoutedEventArgs e)
        {
            ClientServicesWindow clientServicesWindow = new ClientServicesWindow(clientsGrid.SelectedItem as Model.Client);
            clientServicesWindow.Show();
        }
    }
}
