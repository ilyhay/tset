﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DE2
{
    internal class Helper
    {
        public static Model.Entities Entities;

        public static Model.Entities GetContext()
        {
            if (Entities == null)
            {
                Entities = new Model.Entities();
            }
            return Entities;
        }

        //Получение количества клиентов в базе данных
        public static int GetClientsQuantity()
        {
            int count = GetContext().Client.Count();
            return count;
        }


        //Получение даты последнего посещения клиента
        public static DateTime GetClientLastVisitDateTime(Model.Client client)
        {
            //Получение списка посещений клиента
            var clientServiceList = GetContext().ClientService.Where(clientService => clientService.ClientID.Equals(client.ID)).ToList();

            DateTime lastVisitDateTime = client.RegistrationDate;
            foreach (Model.ClientService clientService in clientServiceList)
            {
                if (clientService.StartTime.CompareTo(lastVisitDateTime) > 0)
                    lastVisitDateTime = clientService.StartTime;
            }
            return lastVisitDateTime;
        }

        //Получение количества посещений клиента
        public static int GetClientNumberVisits(Model.Client client)
        {
            //Получение списка посещений клиента
            var clientServiceList = GetContext().ClientService.Where(clientService => clientService.ClientID.Equals(client.ID)).ToList();

            return clientServiceList.Count();
        }


        //Получение списка посещений клиента
        public static List<Model.ClientService> GetClientVisitList(Model.Client client)
        {
            //Получение списка посещений клиента
            var clientServiceList = GetContext().ClientService.Where(clientService => clientService.ClientID.Equals(client.ID)).ToList();

            return clientServiceList;
        }
    }
}
